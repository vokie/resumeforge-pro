
---

# PART 4: 7 PSYCHOLOGY FRAMEWORKS (NOTION EXCLUSIVE)

*These detailed psychology breakdowns are exclusive to the Notion template version.*

---

## FRAMEWORK 1: INFORMATION GAP THEORY (George Loewenstein)

**Core Principle:** Curiosity is a form of cognitive deprivation. When we perceive a gap between what we know and what we want to know, we experience an itch that demands scratching.

**How It Works:**
- The human brain is a prediction machine. When a hook creates a prediction gap, the brain MUST resolve it.
- This creates a "loose end" in working memory that persists until closure is achieved.
- The more specific the gap, the stronger the curiosity.

**Hook Application:**
- Vague gap: "I discovered something interesting." (Weak)
- Specific gap: "I discovered why 97% of threads fail after the 5th tweet." (Strong)
- The specific number (97%) and specific failure point (5th tweet) create a precise gap.

**Examples from This Vault:**
- "The real reason your content isn't going viral has nothing to do with quality."
- "47 specific hooks that generated $12,000 in 30 days. Here's the breakdown."

**Action Step:** Before writing any hook, ask: "What specific piece of information am I withholding that my audience desperately wants?"

---

## FRAMEWORK 2: SOCIAL PROOF (Robert Cialdini)

**Core Principle:** We determine what is correct by finding out what other people think is correct. In uncertainty, we look to the crowd.

**Types of Social Proof in Hooks:**
1. **Expert Social Proof:** "The world's best copywriters use this one word..."
2. **User Social Proof:** "10,000 creators have used this hook..."
3. **Celebrity Social Proof:** "This is the exact framework [Famous Creator] uses..."
4. **Certification Social Proof:** "I tested 1,000 tweets and found..."

**The Data Principle:** Specific numbers outperform vague claims.
- Weak: "Many people use this."
- Strong: "47 creators used this hook to grow 10K followers in 30 days."

**Examples from This Vault:**
- "I analyzed 1,000 viral tweets. 87% of them start with one of these 5 hooks."
- "My threads average 50k impressions. Here's what I do differently."

**Action Step:** Include at least one specific number, outcome, or authority reference in every social proof hook.

---

## FRAMEWORK 3: LOSS AVERSION & FOMO (Daniel Kahneman / Amos Tversky)

**Core Principle:** Losses loom larger than gains. The pain of losing $100 is roughly twice as powerful as the pleasure of gaining $100.

**How to Apply in Hooks:**
1. **Frame opportunities as potential losses:** "Most people will sleep on this trend..."
2. **Create urgency through scarcity:** "The AI window is closing. In 6 months..."
3. **Highlight what they'll miss:** "Your competitors aren't talking about this yet..."

**The FOMO Formula:**
[Time-sensitive opportunity] + [What happens if they miss it] + [How to act now]

**Examples from This Vault:**
- "Most people will sleep on this trend and wake up in 2 years realizing they missed the biggest opportunity of the decade."
- "You have 90 days before your niche is flooded with AI-generated content."

**Action Step:** For every urgency hook, explicitly state what the reader will LOSE by not acting, not just what they'll gain by acting.

---

## FRAMEWORK 4: AUTHORITY & CREDIBILITY

**Core Principle:** People are more likely to follow recommendations from perceived experts and authority figures.

**Authority Signals in Hooks:**
1. **Experience-based:** "After 5 years of building audiences..."
2. **Data-based:** "I studied 1,000 viral tweets..."
3. **Result-based:** "I built a 6-figure audience in 12 months..."
4. **Client-based:** "I've helped 200+ creators monetize..."

**The Credibility Ladder:**
- Level 1: "I think..." (Opinion)
- Level 2: "I noticed..." (Observation)
- Level 3: "I tested..." (Experimentation)
- Level 4: "I analyzed 1,000..." (Data)
- Level 5: "I built X to Y..." (Results)

**Examples from This Vault:**
- "I built a 6-figure audience in 12 months. Here's the roadmap."
- "I've been featured in Forbes, TechCrunch, and Wired. Here's how."

**Action Step:** Upgrade your authority signals. Replace "I think" with "I tested" or "I analyzed."

---

## FRAMEWORK 5: PATTERN INTERRUPT

**Core Principle:** The human brain filters out predictable information to conserve energy. To capture attention, you must violate expectations.

**Types of Pattern Interrupts:**
1. **Contrarian:** "Everything you've heard about X is wrong."
2. **Paradox:** "The best way to grow is to stop trying to grow."
3. **Unexpected Comparison:** "Building an audience is like compound interest..."
4. **Shocking Specificity:** "I made $0 for 847 days before my first sale."

**The Surprise-Relevance Balance:**
- Surprising but irrelevant: Clickbait (damages trust)
- Surprising AND relevant: Pattern interrupt (builds engagement)

**Examples from This Vault:**
- "Most creators are wrong about this. Here's what actually works."
- "Why the world's best copywriters use this one word in every headline."

**Action Step:** Ask: "What does my audience expect me to say? Now say the opposite—but back it up with evidence."

---

## FRAMEWORK 6: THE CURIOSITY LOOP

**Core Principle:** Curiosity is strongest when the answer feels JUST out of reach—achievable but not obvious.

**The Curiosity Curve:**
- Too easy: "Water is wet." (No curiosity)
- Just right: "The chemical structure of water makes it behave unlike any other liquid." (Curiosity)
- Too hard: "Quantum field theory explains water's anomalous properties through gauge symmetry." (Gives up)

**Creating Effective Curiosity Loops:**
1. Promise specific value
2. Withhold the mechanism
3. Make the answer feel accessible
4. Deliver in the content

**Examples from This Vault:**
- "I found a hidden AI prompt that writes better hooks than 99% of creators."
- "The actual psychology behind why people click. It's not complicated."

**Action Step:** Rate your hook's curiosity on a 1-10 scale. If it's below 7, make the gap more specific and the answer more accessible.

---

## FRAMEWORK 7: NARRATIVE TRANSPORTATION

**Core Principle:** When people are absorbed in a story, their analytical resistance drops. They're more persuadable and more likely to remember the message.

**Story Elements That Transport:**
1. **Relatable protagonist:** "I was just like you..."
2. **Clear transformation:** "From X to Y"
3. **Specific details:** "My first thread got 3 likes."
4. **Emotional stakes:** "I was about to quit..."

**The Story Hook Formula:**
[Relatable starting point] + [Unexpected obstacle or realization] + [Hint at transformation]

**Examples from This Vault:**
- "I used to spend 3 hours on a tweet that got 12 likes. Then I discovered this pattern."
- "I was the person who read every article but never implemented anything. The shift that changed everything..."

**Action Step:** Every story hook should answer: Who? What happened? Why does it matter? In one sentence each.

---

# PART 5: ENHANCED BONUSES (NOTION EXCLUSIVE)

---

## BONUS #1: AI HOOK GENERATOR — 10 PREMIUM PROMPTS

*The PDF version includes 5 prompts. The Notion version includes 10 advanced prompts.*

### Prompt 6: The Contrarian Hook Generator
"I need contrarian hooks for [TOPIC]. Generate 5 hooks that challenge conventional wisdom about [TOPIC]. Each hook should:
1. State a commonly accepted belief
2. Contradict it with a specific insight
3. Create curiosity about the evidence"

### Prompt 7: The Story Hook Generator
"I need story-based hooks for [TOPIC]. Generate 5 hooks that:
1. Start with a relatable struggle or situation
2. Hint at a transformation or realization
3. Use specific numbers or timeframes
4. Create an emotional connection"

### Prompt 8: The Comparison Hook Generator
"I need comparison hooks for [TOPIC]. Generate 5 hooks that compare:
1. Before/After scenarios
2. Common approach vs. better approach
3. Amateur vs. professional methods
Make each comparison specific and data-driven where possible."

### Prompt 9: The Urgency Hook Generator
"I need urgency-based hooks for [TOPIC]. Generate 5 hooks that:
1. Identify a time-sensitive opportunity
2. Explain what happens if they wait
3. Provide a specific timeframe
4. Create FOMO without being manipulative"

### Prompt 10: The Niche-Specific Hook Generator
"I need hooks specifically for [NICHE] creators. Generate 5 hooks that:
1. Use niche-specific terminology
2. Address pain points unique to [NICHE]
3. Reference common experiences in [NICHE]
4. Feel like they were written by someone inside [NICHE]"

---

## BONUS #4: WEEKLY CONTENT PLANNER (NOTION EXCLUSIVE)

### The Hook Rotation System

To maximize engagement, rotate through different hook types throughout the week:

**Monday:** Question Hook (engagement focus)
**Tuesday:** Listicle/Number Hook (bookmark focus)
**Wednesday:** Story Hook (connection focus)
**Thursday:** Contrarian Hook (discussion focus)
**Friday:** Social Proof Hook (authority focus)
**Saturday:** Curiosity Hook (viral potential)
**Sunday:** Direct Address Hook (community focus)

### Weekly Planning Template

| Day | Hook Type | Topic | Hook (Draft) | Posted | Performance |
|-----|-----------|-------|--------------|--------|-------------|
| Mon | Question | | | | |
| Tue | Listicle | | | | |
| Wed | Story | | | | |
| Thu | Contrarian | | | | |
| Fri | Social Proof | | | | |
| Sat | Curiosity | | | | |
| Sun | Direct Address | | | | |

### Content Batch Strategy

**Batch Day 1 (Ideation):** Browse Hook Database, select 7 hooks for the week
**Batch Day 2 (Drafting):** Write body content for each hook
**Batch Day 3 (Scheduling):** Schedule posts using your preferred tool
**Daily (5 min):** Review performance, adjust next week's plan

---

# PART 6: NOTION TEMPLATE SETUP GUIDE

## How to Use This Template

### The Hook Database
- **Filter by Category:** Find hooks for your specific content type
- **Filter by Trigger:** Match hooks to your psychological goal
- **Sort by Length:** Find hooks that fit your platform's constraints
- **Add Your Own:** Click "New" to add hooks you discover

### The Performance Tracker
- Log every post with the hook you used
- Track impressions, engagement rate, and follower growth
- Use the "Best Performers" view to identify your top 20%
- Double down on what works for YOUR audience

### The Psychology Frameworks
- Read one framework per week
- Apply it intentionally to your content
- Track which frameworks drive the best results

### The Weekly Planner
- Plan your week's content in one session
- Rotate hook types for variety
- Track what you posted and how it performed

---

# NOTION TEMPLATE EXCLUSIVE FEATURES

| Feature | PDF Version | Notion Version |
|---------|-------------|----------------|
| Total Hooks | 526 | 726 (+200) |
| Hook Categories | 9 | 13 (+4 new sections) |
| Hook Formulas | 25 | 25 |
| AI Prompts | 5 | 10 (+5 advanced) |
| Psychology Frameworks | 0 | 7 (exclusive) |
| Interactive Database | No | Yes (filter/sort) |
| Performance Tracker | Printable | Interactive database |
| Weekly Planner | No | Yes (exclusive) |
| Customizable | No | Yes (add your own hooks) |
| Updates | Static | Template updates |

---

*Viral Hook Vault Pro — Notion Template Version*
*By @vokie123*
*For support and updates: [Your contact info]*

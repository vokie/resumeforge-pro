# Notion Template Setup Guide

## Overview
This guide helps you set up the Viral Hook Vault Pro Notion Template.

## Step 1: Create the Main Page
1. In Notion, create a new page called "Viral Hook Vault Pro"
2. Add an icon (suggested: 🎯)
3. Add a cover image

## Step 2: Create Sub-Pages
Create these sub-pages inside the main page:

### 1. 🪝 Hook Database
- Create an inline database
- Import `hooks.csv` using Notion's CSV import feature
- Set up these properties:
  - Number (Title)
  - Hook (Text)
  - Use For (Select)
  - Trigger (Select)
  - Section (Select)
  - Platform (Select)
  - Length (Select: Short/Medium/Long)
  - Status (Select: Ready/Used/Favorite)

### 2. 🧠 Psychology Frameworks
- Create a page with the 7 frameworks
- Each framework gets its own sub-page or toggle block

### 3. 📝 Hook Formulas
- Create a database
- Import `formulas.csv`
- Properties: Formula (Title), Structure, Example A, Example B, When to Use

### 4. 📊 Performance Tracker
- Create a database
- Import `tracker.csv`
- Properties: Date, Post Type, Hook Used, Hook Category, Impressions, Engagement Rate, Likes, Retweets, Replies, New Followers, Notes, Status

### 5. 📅 Weekly Content Planner
- Create a database
- Import `planner.csv`
- Properties: Day, Hook Type, Topic, Hook Draft, Content Outline, Posted (Checkbox), Performance Notes

### 6. 🤖 AI Prompt Generator
- Create a page with all 10 prompts
- Organize by category

### 7. 📈 Growth Cheat Sheet
- Create a page with best practices
- Include posting times, thread structures, engagement tactics

## Step 3: Set Up Database Views

### Hook Database Views:
1. **All Hooks** (default) - shows everything
2. **By Category** - group by Section
3. **By Trigger** - group by Trigger
4. **Favorites** - filter Status = Favorite
5. **Short Hooks** - filter Length = Short
6. **Unused** - filter Status = Ready

### Performance Tracker Views:
1. **All Posts** (default)
2. **Best Performers** - filter Engagement Rate > 8%
3. **This Month** - filter Date within last 30 days
4. **By Hook Category** - group by Hook Category

## Step 4: Customize
- Add your own hooks to the database
- Mark your favorite hooks
- Track your performance
- Plan your weekly content

## Step 5: Share Template
Once set up, click "Share" → "Share to web" → enable "Allow duplicate as template"
Copy the link for your Gumroad product.

## File List
- `hooks.csv` - 698 hooks for import
- `formulas.csv` - 25 hook formulas
- `tracker.csv` - Performance tracker template
- `planner.csv` - Weekly content planner template
